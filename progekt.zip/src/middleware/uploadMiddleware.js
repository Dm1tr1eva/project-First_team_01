import multer from "multer";
import createHttpError from "http-errors";

// Ліміт 1MB — згідно ТЗ (аватар користувача, фото статті)
export const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 1 * 1024 * 1024,
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(createHttpError(400, "Only images allowed"), false);
    }
  },
});
