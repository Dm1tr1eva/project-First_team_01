export const CATEGORIES = ["popular", "general"];
